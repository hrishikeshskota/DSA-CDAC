public class BST {
	Node root;

	BST() {
		root = null;
	}

	int count = 0;

//////////////////////////////////////////////////////////////////////////////////////

	void insert(int num) {
		root = insertRec(root, num);
	}

	Node insertRec(Node current, int num) {
		if (current == null) {
			return new Node(num);
		}
		if (num < current.value) {
			current.left = insertRec(current.left, num);
		}

		if (num > current.value) {
			current.right = insertRec(current.right, num);
		}

		return current;
	}

	void inorder() {
		inorderRec(root);
	}

	// Recursive in-order traversal
	void inorderRec(Node current) {
		if (current != null) {
			inorderRec(current.left);
			System.out.print(current.value + " ");
			inorderRec(current.right);
		}
	}

//////////////////////////////////////////////////////////////////////////////////////
	void preorder() {
		preorderRec(root);
	}

	void preorderRec(Node current) {
		if (current != null) {
			System.out.print(current.value + " ");
			preorderRec(current.left);
			preorderRec(current.right);

		}
	}

//////////////////////////////////////////////////////////////////////////////////////    
	void postorder() {
		postorderRec(root);
	}

	void postorderRec(Node current) {
		if (current != null) {
			postorderRec(current.left);
			postorderRec(current.right);
			System.out.print(current.value + " ");

		}
	}

//////////////////////////////////////////////////////////////////////////////////////
	int tempcount() {
		TempCountRec(root);
		return count;
	}

	void TempCountRec(Node current) {
		if (current != null) {
			TempCountRec(current.left);
			TempCountRec(current.right);
			// System.out.print(current.value+" ");
			count++;
		}

	}
//////////////////////////////////////////////////////////////////////////////////////
int CountLeafNode() {
	CountLeafNoderec(root);
	return count;
}

void CountLeafNoderec(Node current) {
	if(current == null) {
		count++;
	}
	if (current != null) { 
		CountLeafNoderec(current.left);
		CountLeafNoderec(current.right);
		// System.out.print(current.value+" ");
		//count++;
	}
	
	
}

}

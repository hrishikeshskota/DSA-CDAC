public class Node {
    int value;
    Node left;
    Node right;

    Node(int data){
        this.value=data;
        this.left=null;
        this.right=null;
    }

}

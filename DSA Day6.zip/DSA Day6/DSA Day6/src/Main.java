public class Main {
	public static void main(String[] args) {
		BST tree = new BST();
		tree.insert(50);
		tree.insert(30);
		tree.insert(20);
		tree.insert(40);
		tree.insert(25);
		tree.insert(55);
		tree.insert(60);
		tree.insert(52);
		tree.insert(19);
		tree.insert(77);

//       tree.inorder();
//        System.out.println();
//       tree.preorder();
//        System.out.println();
//        tree.postorder();
//        System.out.println();

		int count = tree.CountLeafNode();
		System.out.println("Number of nodes = " + count);

	}
}